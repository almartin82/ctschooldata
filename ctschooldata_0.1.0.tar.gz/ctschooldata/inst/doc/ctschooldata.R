## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  warning = FALSE
)

## ----eval=FALSE---------------------------------------------------------------
# # install.packages("remotes")
# remotes::install_github("almartin82/ctschooldata")

## ----eval=FALSE---------------------------------------------------------------
# library(ctschooldata)
# library(dplyr)
# 
# # Check available years
# years <- get_available_years()
# print(years)
# # [1] 2007 2008 2009 2010 2011 2012 2013 2014 2015 2016 2017 2018 2019 2020 2021 2022 2023 2024
# 
# # Fetch enrollment data for a single year
# enr_2015 <- fetch_enr(2015)
# 
# # Fetch multiple years
# enr_multi <- fetch_enr_multi(2010:2015)

## ----eval=FALSE---------------------------------------------------------------
# # District totals
# district_totals <- enr_2015 |>
#   filter(is_district, subgroup == "total_enrollment", grade_level == "TOTAL") |>
#   arrange(desc(n_students))
# 
# # Grade-level enrollment for a specific district
# district_grades <- enr_2015 |>
#   filter(district_name == "Achievement First Bridgeport Academy Inc",
#          subgroup == "total_enrollment",
#          grade_level != "TOTAL")

## ----eval=FALSE---------------------------------------------------------------
# # Fetch historical data with real enrollment counts
# enr_2015 <- fetch_enr(2015)
# 
# # Check a specific district's enrollment
# enr_2015 |>
#   filter(district_name == "Achievement First Bridgeport Academy Inc",
#          grade_level == "TOTAL") |>
#   select(district_name, grade_level, n_students)

## ----eval=FALSE---------------------------------------------------------------
# # Check if data contains binary flags
# enr_2024 <- fetch_enr(2024)
# max(enr_2024$n_students, na.rm = TRUE)  # Will be 1 if binary flags

## ----eval=FALSE---------------------------------------------------------------
# # Import manually downloaded EdSight data
# enr_2024 <- import_local_enr(
#   "~/Downloads/CT_Enrollment_2023-24.xlsx",
#   end_year = 2024
# )
# 
# # Data is cached for future use
# enr_2024 <- fetch_enr(2024)  # Uses cached data

## ----eval=FALSE---------------------------------------------------------------
# # Suppression markers are converted to NA
# safe_numeric("-9999")  # Returns NA
# safe_numeric("<5")     # Returns NA
# safe_numeric("*")      # Returns NA

## ----eval=FALSE---------------------------------------------------------------
# # Check if data has actual enrollment counts
# enr <- fetch_enr(2015)
# 
# # Real enrollment data has max > 1
# max_val <- max(enr$n_students, na.rm = TRUE)
# if (max_val > 1) {
#   message("Data contains actual enrollment counts")
# } else {
#   message("Data contains binary grade-offering flags only")
# }
# 
# # Check for any remaining negative values (should be none)
# neg_count <- sum(enr$n_students < 0, na.rm = TRUE)
# stopifnot(neg_count == 0)

## ----eval=FALSE---------------------------------------------------------------
# # View cache status
# cache_status()
# 
# # Clear all cached data
# clear_cache()
# 
# # Clear specific year
# clear_cache(2024)

## ----eval=FALSE---------------------------------------------------------------
# # 2023-24 school year
# enr_2024 <- fetch_enr(2024)
# 
# # Format for display
# format_school_year(2024)  # Returns "2023-24"
# 
# # Parse from display format
# parse_school_year("2023-24")  # Returns 2024

