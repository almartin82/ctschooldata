# This file is part of the standard testthat setup

library(testthat)
library(ctschooldata)

test_check("ctschooldata")
