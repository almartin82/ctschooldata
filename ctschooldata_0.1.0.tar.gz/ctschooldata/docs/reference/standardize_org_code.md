# Standardize district/school identifiers

Connecticut uses 7-digit organization codes.

## Usage

``` r
standardize_org_code(code)
```

## Arguments

- code:

  Organization code

## Value

Standardized 7-character code
