# Fetch Connecticut education directory

Downloads the current list of schools and districts from CT Open Data.

## Usage

``` r
fetch_education_directory()
```

## Value

Data frame with organization information
