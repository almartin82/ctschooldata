# Try fetching enrollment data from CTData.org

Checks for enrollment datasets on CTData.org via CKAN API.

## Usage

``` r
try_ctdata_org(end_year)
```

## Arguments

- end_year:

  School year end

## Value

Data frame or NULL if not found
