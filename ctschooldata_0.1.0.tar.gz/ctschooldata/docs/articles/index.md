# Articles

### Key Insights

- [15 Insights from Connecticut School Enrollment
  Data](https://almartin82.github.io/ctschooldata/articles/enrollment_hooks.md):
